```bash
export GRAFANA_URL="https://grafana.localhost"
export GRAFANA_TOKEN="gf_sa_xxx"
export MIMIR_URL="https://mimir:9009/prometheus"
export FOLDER_TITLE="Edges"
export FOLDER_UID="edges-folder"
export TEMPLATE_PATH="central/grafana/dashboards/edge-template.json"
export DATASOURCE_PREFIX="Mimir - "

EDGE=edge-c python3 tools/publish_grafana_edges.py


```


```powershell

$env:GRAFANA_URL      = "http://localhost:8000"
#$env:GRAFANA_URL      = "https://grafana.localhost"
$env:GRAFANA_TOKEN    = "glsa_BNVngWiVBWeWTZwfacbYY9024VjwmY7r_7deb86a6"
$env:MIMIR_URL        = "https://mimir:9009/prometheus" 
$env:TEMPLATE_PATH    = "central/grafana/dashboards/edge-template.json"
$env:DATASOURCE_PREFIX = "Mimir - "
$env:FOLDER_TITLE     = "Edges"
$env:EDGE             = "edge-a, edge-b, edge-c"
$env:TENANT           = "edge-a:p1,edge-b:p2,edge-c:p3
$env:CA_CERT_PATH      =  "certs/ca.crt"
$env:CLIENT_CERT_PATH  = "central/certs/grafana.crt"
$env:CLIENT_KEY_PATH  = "central/certs/grafana.key"



python3 tools/publish_grafana_edges.py


```


| Component                | Function                                                                |
| ------------------------ | ----------------------------------------------------------------------- |
| **Distributor**          | Entry point for metric ingestion (`/api/v1/push`).                      |
| **Ingester**             | Holds recent data in memory; flushes blocks to long-term storage.       |
| **Querier**              | Executes PromQL queries by reading from ingesters + storage.            |
| **Query-frontend**       | Receives PromQL queries, caches results, load-balances across Queriers. |
| **Store-gateway**        | Reads historical blocks from object storage.                            |
| **Compactor**            | Compacts small blocks into larger, optimized ones for efficiency.       |
| **Ruler / Alertmanager** | (Optional) Evaluate rules and send alerts, Prometheus-style.            |


| Variable            | Required | Purpose                                             |
| ------------------- | -------- | --------------------------------------------------- |
| `GRAFANA_URL`       | Yes      | Grafana API URL                                     |
| `GRAFANA_TOKEN`     | Yes      | API token for Grafana                               |
| `MIMIR_URL`         | Yes      | Mimir/Prometheus backend URL (as seen from Grafana) |
| `TEMPLATE_PATH`     | Yes      | Path to the dashboard JSON template                 |
| `FOLDER_TITLE`      | Yes      | Folder where dashboards will be created             |
| `DATASOURCE_PREFIX` | Yes      | Prefix used when naming datasources                 |
| `EDGE`              | Yes      | List of edges or a single edge                      |
| `TENANT`            | Yes      | Single tenant value or mapping of edge-to-tenant    |
| `CA_CERT_PATH`      | Yes      | Path to the CA certificate (mTLS)                   |
| `CLIENT_CERT_PATH`  | Yes      | Path to the client certificate                      |
| `CLIENT_KEY_PATH`   | Yes      | Path to the client private key                      |


edge-a = logical edge ID you show in dashboards & labels

p1 = tenant ID that Mimir uses internally

We need both pieces:

edge-a drives:
- datasource name (Mimir - Edge A)
- dashboard name
- UID suffix
- how your metrics are labeled (edge="edge-a")

--------

edge-a = logical edge ID you show in dashboards & labels

p1 = tenant ID that Mimir uses internally

We need both pieces:

edge-a drives:

datasource name (Mimir - Edge A)

dashboard name

UID suffix

how your metrics are labeled (edge="edge-a")