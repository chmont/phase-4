import os
from flask import Flask
from prometheus_flask_exporter import PrometheusMetrics

app = Flask(__name__)
# This registers /metrics automatically (default path is "/metrics")
metrics = PrometheusMetrics(app, path='/metrics')

@app.get("/")
def hello():
    return "<h1>hello from edge A!<h1> "

if __name__ == "__main__":
    port = int(os.getenv("PORT", "8080"))
    app.run(host="0.0.0.0", port=port)


# @app.route('/')
# def hello_world():
#     # A simple greeting message
#     greeting = "Hello, World!"
#     # A bonus message to show it's running in a container
#     container_msg = "I'm being watched O-O"
#     return f"<h1>{greeting}</h1> <p1>{container_msg}<p1>"

# if __name__ == '__main__':
#     # Binds to 0.0.0.0 to be accessible outside the container
#     # Uses the PORT environment variable if available, otherwise defaults to 8080
#     app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))