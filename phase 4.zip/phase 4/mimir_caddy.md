
# 📊 Grafana Mimir, Prometheus, and Caddy Architecture Overview

## 🧭 What Grafana Mimir Is

**Grafana Mimir** is an open-source, horizontally scalable, long-term metrics storage system that is API-compatible with Prometheus.

That means:
- It understands Prometheus data formats and queries (PromQL).
- But it’s designed to scale beyond what a single Prometheus instance can handle.

💡 Think of Mimir as Prometheus’s “big brother” — same brain (PromQL, metrics model), but built to handle huge data volumes, many tenants, and long retention periods.

---

## ⚙️ How Prometheus Works (and Its Limits)

Prometheus is perfect for local monitoring — it:
- Scrapes metrics from exporters and applications.
- Stores data locally in its own time-series database (TSDB).
- Runs queries with PromQL.

However, Prometheus has some **limitations** when used at larger scale:

| Limitation | Description |
|-------------|--------------|
| **Single-node storage** | Metrics stored on local disk — not shared or replicated. |
| **Limited retention** | Usually only days or weeks before old data is deleted. |
| **No native clustering** | One Prometheus = one node = single point of failure. |
| **No multi-tenant isolation** | Hard to securely separate metrics for different sources (edges, customers, etc.). |

In short, **Prometheus is a collector, not a long-term store.**

---

## 🚀 What Grafana Mimir Adds

Mimir was built by Grafana Labs (based on the Cortex project) to solve those scaling and reliability problems. It’s Prometheus re-imagined for **centralization**.

---

### 🔹 1️⃣ Horizontal Scalability (Expanded)

Prometheus was designed to be **simple and self-contained**, but that also means it’s limited by a single machine’s CPU, memory, and disk.  
When metric volume increases — say you have dozens of nodes, containers, or edge collectors — Prometheus eventually becomes a bottleneck.

Grafana **Mimir solves this** through a **horizontally scalable, microservices architecture**.

#### 🧱 How Horizontal Scaling Works in Mimir

Instead of one monolithic Prometheus process, Mimir splits responsibilities across multiple components:

| Component | Role | Scales With |
|------------|------|-------------|
| **Distributors** | Receive incoming data from Prometheus `remote_write` and validate it | Write throughput |
| **Ingesters** | Temporarily buffer and compress metric samples in memory before storing them | Ingestion volume |
| **Compactors** | Merge and deduplicate metric blocks in long-term storage | Retention size |
| **Querier / Query Frontend** | Handle PromQL queries and coordinate parallel reads across storage | Query load |
| **Store-Gateway** | Reads and caches data from object storage for queries | Storage and query performance |

Each of these components can run on its own container or VM.  
When you add more Prometheus edges or collect higher metric volumes, you can simply **add more replicas** of any component (e.g., more Ingesters or Queriers).

This is what makes Mimir “**cloud-native Prometheus**.”  
You’re no longer bound by a single node’s resources — you can scale out linearly as your infrastructure grows.

#### 🧮 Example

If one Prometheus instance can handle 1 million active time series, a 5-node Mimir cluster can handle roughly 5 million — with the same performance.  
That’s ideal for enterprise or multi-region monitoring setups.

---

### 🔹 2️⃣ Long-Term Storage

Unlike Prometheus, which stores on local disk, Mimir supports object storage backends such as:
- AWS S3
- Azure Blob Storage
- Google Cloud Storage
- MinIO or local S3-compatible storage

You can store metrics for months or even years, enabling:
- Trend analysis across long time ranges.
- Capacity planning (CPU, memory, network growth).
- Compliance or audit retention requirements.

✅ **Eventually, you plan to connect Mimir to Azure Blob Storage**, making your stack cloud-ready and enabling cost-efficient long-term metric retention.

---

### 🔹 3️⃣ Multi-Tenant Architecture (Expanded)

#### 🧩 The Problem It Solves

In a traditional Prometheus setup:
- Each Prometheus instance stores only **its own metrics**.
- There’s **no built-in concept of tenants** — all data belongs to one logical user.

If you wanted to collect metrics from multiple environments (e.g., staging, production, customer A, customer B), you’d need:
- Separate Prometheus servers, and  
- Separate dashboards, or  
- Manual federation setups.

This quickly becomes hard to manage and insecure — metrics can accidentally mix or be queried across environments.

#### 🧠 How Multi-Tenancy Works in Mimir

Mimir introduces **tenant isolation** using a simple but powerful mechanism:
Every Prometheus `remote_write` request must include an HTTP header:
```
X-Scope-OrgID: <tenant_id>
```
For example:
- Edge-A (Prometheus A) → `X-Scope-OrgID: p1`
- Edge-B (Prometheus B) → `X-Scope-OrgID: p2`

When Mimir receives data:
1. It verifies the client’s certificate (mTLS authentication).  
2. It reads the `X-Scope-OrgID` header.  
3. It stores the metrics in a **separate namespace** (tenant p1, p2, etc.) in the backend store.

When Grafana queries Mimir:
- Each datasource is configured to include that same header:
  ```yaml
  jsonData:
    httpHeaderName1: X-Scope-OrgID
  secureJsonData:
    httpHeaderValue1: p1
  ```
- This tells Mimir:  
  “Only return metrics that belong to tenant p1.”

#### 🧱 Why It Matters
- **Security:** Tenants can’t see or query each other’s data.  
- **Organization:** You can logically group metrics per region, department, or environment.  
- **Scalability:** Adding a new edge is as easy as adding a new tenant and datasource.  
- **Future-Proofing:** This matches how SaaS observability systems work (e.g., Grafana Cloud, Datadog).

#### 💡 Example
| Tenant | Source | OrgID | Grafana Data Source | Description |
|---------|---------|--------|--------------------|-------------|
| p1 | Edge-A Prometheus | p1 | “Mimir – Edge A” | Edge metrics from cluster A |
| p2 | Edge-B Prometheus | p2 | “Mimir – Edge B” | Edge metrics from cluster B |
| p3 | Future Edge | p3 | “Mimir – Edge C” | Can be added anytime |

Each datasource in Grafana uses its own `X-Scope-OrgID`, so queries are automatically isolated.

#### 🔐 In Practice

In your stack:
- **Edges (Prometheus)** → push metrics to central Mimir with unique tenant IDs.  
- **Mimir** → stores and segregates them internally.  
- **Grafana** → has multiple datasources, one per edge/tenant.  
- **Caddy** → proxies and secures all traffic with mTLS.

This pattern — *many Prometheus edges feeding one multi-tenant Mimir* — is a modern, production-grade way to centralize observability.

---

## 🧠 Why You Use Mimir in This Project

Your architecture follows the **federated Prometheus pattern**:

1. Each **edge Prometheus** scrapes local metrics.  
2. **Central Mimir** receives all metrics through `remote_write` (secure mTLS).  
3. **Grafana** queries Mimir to visualize everything.

### Benefits:
✅ Unified monitoring of all edges  
✅ Long-term metric storage (eventually in Azure Blob Storage)  
✅ Secure isolation between tenants  
✅ Scalable and fault-tolerant metric ingestion  
✅ PromQL-compatible — no new query language needed

---

## 🏗️ Visual Summary

```
[ Edge-A Prometheus ]                        [ Edge-B Prometheus ] ---> [ Central Grafana Mimir ] ---> [ Azure Blob Storage (future) ]
                               ^
                               |
                           [ Grafana Dashboards ]
```

**Prometheus instances** = short-term scrapers (edge collectors)  
**Mimir** = centralized, long-term storage and query engine  
**Grafana** = unified visualization layer  
**Caddy** = secure HTTPS/mTLS gateway  

---

# 🌐 What Caddy Is

**Caddy** is a modern, open-source web server and reverse proxy written in Go — similar in concept to Nginx or Apache, but designed for **simplicity, security, and automation**.

### At its core, Caddy:
- Serves web content (like any web server).
- Reverse-proxies traffic from one endpoint to another (e.g. `https://grafana.localhost` → `grafana:3000`).
- Handles automatic HTTPS (TLS) configuration and renewal — even for self-signed or local certificates.
- Supports **mTLS**, header manipulation, authentication, rate-limiting, and more out of the box.

💡 Think of it as your “smart doorman” — every request to your monitoring system passes through Caddy first.

---

## 🧩 What “Proxying” Means

When you proxy a service, you make Caddy act as a **middleman** between users (or clients) and your backend services.

Instead of users connecting directly to your apps:

```
Browser → Grafana:3000
Browser → Mimir:9009
```

You set up Caddy as a **gateway**:

```
Browser → Caddy:443 (HTTPS)
             ↳ Grafana:3000
             ↳ Mimir:9009
```

This provides:
- A single HTTPS entry point.
- Centralized TLS/mTLS configuration.
- Hidden internal network ports (Grafana and Mimir are not directly exposed).
- Easier future add-ons like authentication or rate limiting.

---

## 🧱 How You’re Using Caddy in This Project

In your monitoring stack, **Caddy** sits inside the central environment and plays two roles:

### 1️⃣ Public-facing TLS Termination
Caddy listens on ports 80/443 and terminates HTTPS for:
- `https://grafana.localhost`
- `https://mimir.localhost`

It uses the **central certificate** (`central.crt / central.key`) to encrypt traffic between browsers and the monitoring system.

### 2️⃣ Internal Secure Proxying

Caddy then proxies those HTTPS requests inward:

```caddy
grafana.localhost {
    reverse_proxy grafana:3000
    tls /etc/certs/central.crt /etc/certs/central.key
}

mimir.localhost {
    reverse_proxy https://mimir:9009 {
        transport http {
            tls
            tls_server_name mimir
            tls_client_auth /etc/certs/grafana.crt /etc/certs/grafana.key
            tls_trust_pool file /etc/certs/ca.crt
        }
    }
    tls /etc/certs/central.crt /etc/certs/central.key
}
```

### Flow Summary:
- The **browser** connects securely to Caddy.
- Caddy **forwards** the request to Grafana or Mimir.
- For Mimir, Caddy performs **mTLS** using Grafana’s client certs.

---

## 🔐 Why You Added Caddy to the Stack

| Reason | Benefit |
|---------|----------|
| **Unified HTTPS endpoint** | Users only need one secure entry point — no need to expose internal ports. |
| **Simplified certificate management** | Only Caddy handles browser TLS certs; Grafana/Mimir keep simpler configs. |
| **Supports mTLS internally** | Caddy securely authenticates to Mimir on behalf of Grafana. |
| **Security isolation** | Grafana and Mimir are no longer directly reachable from outside the Docker network. |
| **Extensibility** | Easily add authentication, rate-limiting, or access logs later with simple config lines. |
| **Developer-friendly syntax** | Caddyfile is simpler and more readable than Nginx configuration. |

---

## 🧠 Caddy vs. Nginx

| Feature | **Caddy** | **Nginx** |
|----------|------------|-----------|
| **TLS setup** | Automatic (built-in) | Manual (requires OpenSSL directives) |
| **mTLS support** | Built-in & simple | Requires complex configuration |
| **Cert reloads** | Auto-reloads on file change | Must reload service manually |
| **Configuration style** | Human-friendly Caddyfile | Verbose directives |
| **Ideal for** | Containerized & local setups | Large enterprise edge servers |

---

## 🧩 Recap — End-to-End Flow

### External Flow (user-facing)
```
Browser → Caddy (HTTPS)
Caddy → Grafana (HTTP) or Mimir (mTLS)
```

### Internal Flow (service-to-service)
```
Grafana → Caddy → Mimir (mTLS)
Prometheus Edges → Mimir (mTLS)
```

Everything flows securely through Caddy, and all internal services remain isolated inside the Docker network.

✅ **In Short:**
- **Caddy is your secure front door.**
- **Grafana and Mimir stay behind it — safe and private.**
- **TLS and mTLS are handled automatically** without manual restarts or OpenSSL complexity.
- Keeps your monitoring stack **modular, secure, and production-ready.**