
# 🔐 Understanding Certificates, mTLS, and Multi-Tenant Setup with Grafana Mimir

## 🧾 Why Each Service Needs Its Own Certificate

Each certificate represents a unique identity within your monitoring network.
Think of certificates as **digital ID cards** that allow every component (Grafana, Mimir, and each Edge Prometheus) to securely prove who it is before exchanging data.

| Service | Certificate | Purpose | Acts As |
|----------|--------------|----------|---------|
| **Grafana** | `grafana.crt / grafana.key` | Lets Grafana prove its identity when querying Mimir | Client |
| **Mimir (Central)** | `central.crt / central.key` | Proves Mimir is the real central storage system | Server |
| **Edge A / B Prometheus** | `edge-a.crt / edge-b.crt` | Authenticates Prometheus when sending metrics to Mimir | Client |
| **Caddy Proxy** | Uses `central.crt / central.key` for browser HTTPS | Front-end HTTPS terminator | Gateway |
| **CA (Certificate Authority)** | `ca.crt / ca.key` | The “root of trust” that signs all certificates | Authority |

### 🧩 Why They Must Be Unique
- Prevents **impersonation** — if one service’s key leaks, others remain safe.
- Enables **revocation** — you can revoke one certificate without affecting others.
- Allows **fine-grained access control** — e.g., Mimir can distinguish between different edges or Grafana.
- Mirrors **real-world best practices** — like client certificates in enterprise PKI networks.

---

## 🔄 How Each Service Communicates

### 1️⃣ Edge Prometheus → Central Mimir
- Each Prometheus instance scrapes local targets (containers, nodes, exporters).
- It then pushes metrics to Mimir using `remote_write` over HTTPS with mTLS.
- Prometheus presents its client cert (e.g. `edge-a.crt`) → Mimir verifies it against the CA.
- Mimir presents its server cert (`central.crt`) → Prometheus verifies it too.

✅ **Result:** Mutual trust — both sides know they’re talking to legitimate peers.  
✅ **Data encrypted in transit** — no metrics exposed on the network.

### 2️⃣ Grafana → Mimir
- Grafana queries Mimir’s Prometheus-compatible API endpoints:
  ```
  /prometheus/api/v1/query
  /prometheus/api/v1/query_range
  ```
- These endpoints expose time-series data stored in Mimir.
- Grafana connects to Mimir over mTLS using its own `grafana.crt` and `grafana.key`.
- Mimir again verifies Grafana’s certificate before allowing queries.
- The connection is proxied through **Caddy**, which handles external HTTPS (browser access) and internal mTLS to Mimir.

✅ **Result:** Grafana can securely visualize all edge metrics aggregated in Mimir.

### 3️⃣ Browser → Grafana (through Caddy)
- The browser connects via `https://grafana.localhost`.
- Caddy terminates TLS using `central.crt / central.key`.
- Grafana sits behind Caddy and never exposes port 3000 directly.
- Caddy can later enforce user auth or SSO, adding another layer of security.

✅ **Result:** End users see a single HTTPS-secure dashboard endpoint.

| Direction | Security Type | Purpose |
|------------|----------------|----------|
| **Edge Prometheus → Mimir** | mTLS | Secure metric ingestion |
| **Grafana → Mimir** | mTLS | Secure querying |
| **Browser → Grafana (via Caddy)** | TLS | Secure user access |
| **Caddy → Mimir** | mTLS | Secure proxy query forwarding |

---

## 🎯 Why Each Edge Has Its Own Data Source in Grafana

Even though both data sources point to the same Mimir endpoint, they are separated because of the **tenant isolation model**.

### 🧱 1️⃣ Mimir is Multi-Tenant by Design
Mimir isn’t just “Prometheus in the cloud.”  
It’s a **multi-tenant metrics store**, meaning it can accept and isolate data from multiple Prometheus instances (edges) safely within one central backend.

Each tenant (edge) is identified by the header:
```
X-Scope-OrgID: p1, p2, p3, ...
```
Mimir enforces **data isolation** — Edge A’s metrics never mix with Edge B’s.  
Grafana uses separate data sources so it knows which tenant’s data to query.

✅ **Result:** You can query Edge A’s metrics independently from Edge B’s, or create dashboards that combine both.

---

### 🧩 2️⃣ Why Not One Global Data Source?
If you only had a single data source:

```
url: https://mimir:9009
```

You’d have to manually switch `X-Scope-OrgID` inside Grafana for every panel or query — not scalable.

By defining one datasource per edge:
- Grafana automatically sends the right tenant header.
- Users can easily switch between data sources in the dropdown.
- Permissions can later be scoped per data source (e.g., Edge A’s users can’t see Edge B’s metrics).

✅ Simplifies querying  
✅ Supports multi-team or multi-region architecture  
✅ Ready for **RBAC (role-based access control)** later

---

### 🌎 3️⃣ The Concept of “Tenant”
Each edge (Prometheus instance) acts as a **tenant** that:
- Collects metrics locally.
- Pushes them to Mimir under its `OrgID` (`p1`, `p2`, …).
- Grafana then queries using that same `OrgID` to fetch the right dataset.

This enables future expansion:
- Edge C → Tenant `p3`
- Edge D → Tenant `p4`
- Even external customers or departments can get isolated telemetry pipelines.

---

### 🔄 4️⃣ How It Works Under the Hood

**Prometheus → Mimir**
- Edge A writes metrics to Mimir with:
  ```
  X-Scope-OrgID: p1
  ```
- Edge B uses:
  ```
  X-Scope-OrgID: p2
  ```
- Mimir stores both sets in **separate tenants**.

**Grafana → Mimir**
- When you query via “Mimir - Edge A” data source, Grafana automatically sends:
  ```
  X-Scope-OrgID: p1
  ```
- Mimir responds with only Edge A’s metrics.

✅ The header is the “key” that decides which tenant’s metrics you get.

---

### 🧠 5️⃣ Benefits of Per-Edge Datasources

| Benefit | Description |
|----------|-------------|
| **Isolation** | Prevents cross-contamination of metrics between edges. |
| **Flexibility** | You can visualize or alert per edge or across all edges. |
| **Security** | Each datasource can later use different credentials or client certs. |
| **Scalability** | Easy to add new edges by adding new datasources. |
| **Troubleshooting** | If one edge fails, others still query fine. |
| **Future-Proofing** | Integrates well with multi-tenant alerting and per-tenant retention. |

---

## 📘 What `central_ext.cnf` Is and Why It Matters

`central_ext.cnf` is a configuration file passed to OpenSSL when signing `central.csr` to generate `central.crt`.

Command used:
```bash
openssl x509 -req -in central.csr -CA ca.crt -CAkey ca.key   -CAcreateserial -out central.crt -days 365 -sha256   -extfile central_ext.cnf
```

It defines **Subject Alternative Names (SANs)** — the hostnames this certificate is valid for.

Example:
```ini
subjectAltName = @alt_names

[alt_names]
DNS.1 = mimir
DNS.2 = central
DNS.3 = mimir.localhost
```

Modern clients (Grafana, Prometheus, Caddy) **require** SANs — they ignore CN (Common Name).  
If SANs are missing, you’ll see an error like:

> `x509: certificate is not valid for any names, but wanted to match mimir`

✅ Adding `central_ext.cnf` fixed that issue by telling OpenSSL:  
> “This certificate is valid for these hostnames.”

| File | Purpose | Used When |
|------|----------|-----------|
| `central.key` | Private key for Mimir | Always |
| `central.csr` | Certificate signing request | Before signing |
| `ca.crt / ca.key` | Certificate Authority | To sign |
| `central.crt` | Final signed certificate | Served by Mimir |
| `central_ext.cnf` | Defines SANs | During signing (`-extfile`) |

✅ **If you change service hostnames**, you must reissue the certificate with an updated `central_ext.cnf`.

---

## 🧠 Summary

- Each service has its own certificate and identity.  
- Mimir verifies clients via mTLS.  
- Grafana queries Mimir’s Prometheus API over HTTPS.  
- Caddy provides a secure HTTPS → mTLS gateway.  
- Each edge Prometheus is a separate tenant with its own OrgID and Grafana datasource.  
- `central_ext.cnf` ensures proper SAN validation to avoid x509 hostname errors.