import json, os, re, requests, sys

GRAFANA_URL     = os.environ["GRAFANA_URL"]
GRAFANA_TOKEN   = os.environ["GRAFANA_TOKEN"]
DATASOURCE_NAME = os.environ.get("DATASOURCE_NAME", "Prometheus")
EDGES           = os.environ.get("EDGES", "edge-a,edge-b").split(",")
FOLDER_TITLE    = os.environ.get("FOLDER_TITLE", "Edges")
FOLDER_UID      = os.environ.get("FOLDER_UID", "edges-folder")
TEMPLATE_PATH   = os.environ.get("TEMPLATE_PATH", "dashboards/edge-template.json")

H = {"Authorization": f"Bearer {GRAFANA_TOKEN}", "Content-Type": "application/json"}

def gget(path):
    r = requests.get(GRAFANA_URL + path, headers=H); r.raise_for_status(); return r.json()

def gpost(path, body):
    r = requests.post(GRAFANA_URL + path, headers=H, data=json.dumps(body)); r.raise_for_status(); return r.json()

def ensure_folder():
    try:
        return gget(f"/api/folders/uid/{FOLDER_UID}")
    except requests.HTTPError:
        return gpost("/api/folders", {"uid": FOLDER_UID, "title": FOLDER_TITLE})

def datasource_uid_by_name(name):
    r = requests.get(f"{GRAFANA_URL}/api/datasources/name/{name}", headers=H)
    r.raise_for_status(); return r.json()["uid"]

def uid_safe(edge):
    uid = re.sub(r"[^a-z0-9_-]", "_", edge.lower())
    return uid[:36]

def main():
    ensure_folder()
    ds_uid = datasource_uid_by_name(DATASOURCE_NAME)

    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()

    for edge in EDGES:
        uid_suffix = uid_safe(edge)
        rendered = (template
            .replace("${EDGE_NAME}", edge)
            .replace("${DATASOURCE_UID}", ds_uid)
            .replace("${UID_SUFFIX}", uid_suffix))

        payload = {
            "dashboard": json.loads(rendered),
            "folderUid": FOLDER_UID,
            "message": f"CI update for {edge}",
            "overwrite": True
        }
        resp = gpost("/api/dashboards/db", payload)
        print(f"Upserted dashboard for {edge} -> {resp.get('url')}")

if __name__ == "__main__":
    main()
